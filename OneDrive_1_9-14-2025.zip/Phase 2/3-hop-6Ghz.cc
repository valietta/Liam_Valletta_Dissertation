/**
 * @file wifi7-3hop.cc
 * @brief ns-3 multi-hop (3-hop) ad hoc experiment targeting Wi-Fi 7 parameters.
 *
 * Topology:
 *   Linear chain: node0 (source) -> node1 (relay) -> node2 (relay) -> node3 (sink)
 *   Positions: 0 m, 20 m, 40 m, 60 m (total path length 60 m)
 *
 * Wireless:
 *   - Standard set to WIFI_STANDARD_80211be (Wi-Fi 7). Depending on ns-3 version,
 *     this may fall back to HE/AX under the hood. I used 160 MHz channel width and 23 dBm TX power. 
 *   - MinstrelHt rate control enables adaptive MCS selection in the presence of loss/attenuation.
 *
 * Channel / Propagation:
 *   - ThreeLogDistancePropagationLossModel to simulate tunnel attenuation.
 *
 * Traffic:
 *   - UDP constant bit rate (OnOffHelper with ConstantRate) at 50 Mbps from node0 -> node3.
 *   - PacketSink at node3 records received bytes.
 *
 * Routing:
 *   - OLSR over an ad-hoc MAC to enable multi-hop forwarding without AP's.
 *
 * Measurements:
 *   - RSSI/Noise monitor via MonitorSnifferRx during the first ~2 s (keeps log small).
 *   - FlowMonitor records throughput, delay, jitter, packet loss (saved as XML).
 *
 * Outputs:
 *   - rssi-3hop-mcs<M>-seed<S>.txt    (PHY-layer RSSI/Noise snapshots)
 *   - wifi7-3hop-mcs<M>-seed<S>.xml   (FlowMonitor KPIs)
 *
 * Notes:
 *  
 *   - targets 6 GHz and up to 320 MHz, but those settings can be swapped if your build supports them.
 *   - MinstrelHt is chosen for adaptive rate control; ConstantRate would fix MCS if you need that.
 *   - OLSR provides dynamic routes. For strictly controlled paths, static routing can be used instead.
 */





#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/wifi-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/olsr-module.h"
#include <sstream>

using namespace ns3;

std::ofstream rssiStream;  // File stream for early RSSI/Noise snapshots



// --- PHY-layer monitor: capture RSSI/Noise on packet reception ----------------
// I only logged for the first ~2 seconds to avoid huge files while still getting
// a snapshot of channel quality during ramp-up.
void MonitorSniffRx(std::string context,
                    Ptr<const Packet> p,
                    uint16_t channelFreqMhz,
                    WifiTxVector txVector,
                    MpduInfo mpduInfo,
                    SignalNoiseDbm signalNoise,
                    uint16_t staId)
{
  double now = Simulator::Now().GetSeconds();
  if (now <= 2.01)
  {
    std::ostringstream log;
    log << now
        << "s RSSI: " << signalNoise.signal
        << " dBm (Noise: " << signalNoise.noise << " dBm)"
        << " on channel " << channelFreqMhz << " MHz"
        << std::endl;
    rssiStream << log.str();
  }
}

int main(int argc, char *argv[])
{
  int seedValue = 1;
  int mcsIndex  = 0;

  CommandLine cmd;
  cmd.AddValue("run", "Seed index for the RNG", seedValue);  // run index (used to vary RNG stream)
  cmd.AddValue("mcs", "Wi-Fi MCS index (kept for filenames)", mcsIndex);
  cmd.Parse(argc, argv);

  SeedManager::SetSeed(12345); // Base RNG seed + selector per run for different seeds across tests
  SeedManager::SetRun(seedValue);


// RSSI log file (tagged by mcs + seed)
  std::ostringstream rssiname;
  rssiname << "rssi-3hop-mcs" << mcsIndex << "-seed" << seedValue << ".txt";
  rssiStream.open(rssiname.str());

// --- 1 Nodes and mobility (linear 3-hop chain) -----------------------------
  NodeContainer nodes;
  nodes.Create(4); // 3-hop path: 0 (src) -> 1 (relay) -> 2 (relay) -> 3 (dst)

  // Mobility (15 m spacing -> total 45 m)
  MobilityHelper mobility;
  Ptr<ListPositionAllocator> pos = CreateObject<ListPositionAllocator>();
  pos->Add(Vector(0.0, 0.0, 0.0));   // node 0
  pos->Add(Vector(20.0, 0.0, 0.0));  // node 1
  pos->Add(Vector(40.0, 0.0, 0.0));  // node 2
  pos->Add(Vector(60.0, 0.0, 0.0));  // node 3
  mobility.SetPositionAllocator(pos);
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.Install(nodes);

  // Channel / propagation
  YansWifiChannelHelper channel;
  channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
  channel.AddPropagationLoss("ns3::ThreeLogDistancePropagationLossModel",
                             "Distance0", DoubleValue(1.0),
                             "Distance1", DoubleValue(50.0),
                             "Distance2", DoubleValue(150.0),
                             "Exponent0", DoubleValue(2.0),   // near-field
                             "Exponent1", DoubleValue(2.5),  // mid
                             "Exponent2", DoubleValue(5.0));  // long distance
  Ptr<YansWifiChannel> wifiChannel = channel.Create();

  // Wi-Fi (set standard BEFORE ChannelSettings)
  WifiHelper wifi;
  wifi.SetStandard(WIFI_STANDARD_80211be);

  YansWifiPhyHelper phy;
  phy.SetChannel(wifiChannel);
  phy.Set("ChannelSettings", StringValue("{0, 160, BAND_5GHZ, 0}")); // change depending on frequency and channel width
  phy.Set("TxPowerStart", DoubleValue(23.0));
  phy.Set("TxPowerEnd",   DoubleValue(23.0));

  wifi.SetRemoteStationManager("ns3::MinstrelHtWifiManager");   //use adaptive MCS selection 

  WifiMacHelper mac;
  mac.SetType("ns3::AdhocWifiMac");
  NetDeviceContainer devices = wifi.Install(phy, mac, nodes);

  // RSSI sniff (first 2s)
  Config::Connect("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Phy/MonitorSnifferRx",
                  MakeCallback(&MonitorSniffRx));

  // Internet stack with OLSR - discovers/maintains routes dynamically in the ad-hoc network.
  OlsrHelper olsr;
  Ipv4ListRoutingHelper list;
  list.Add(olsr, 10);
  InternetStackHelper stack;
  stack.SetRoutingHelper(list);
  stack.Install(nodes);

  // Single shared subnet
  Ipv4AddressHelper address;
  address.SetBase("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer ifs = address.Assign(devices);

  // Traffic: UDP OnOff from node0 -> node3
  uint16_t port = 9;
  std::string dataRateStr = "50Mbps"; // stable-load case

  OnOffHelper onoff("ns3::UdpSocketFactory",
                    InetSocketAddress(ifs.GetAddress(3), port));
  onoff.SetConstantRate(DataRate(dataRateStr), 1472);  // 1472 Byte payload chosen to stay under typical MTU after UDP/IP headers.
  onoff.SetAttribute("StartTime", TimeValue(Seconds(2.0)));
  onoff.SetAttribute("StopTime",  TimeValue(Seconds(30.0)));
  onoff.Install(nodes.Get(0));

  PacketSinkHelper sink("ns3::UdpSocketFactory",
                        InetSocketAddress(Ipv4Address::GetAny(), port));
  ApplicationContainer sinkApp = sink.Install(nodes.Get(3));
  sinkApp.Start(Seconds(1.0));
  sinkApp.Stop(Seconds(30.0));

  // FlowMonitor
  FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();  // KPIs available: throughput, delay, jitter, loss; exported to XML for post-processing.
  monitor->SetAttribute("StartTime", TimeValue(Seconds(0.0)));

  Simulator::Stop(Seconds(31.0));
  Simulator::Run();

  std::ostringstream fname;
  fname << "wifi7-3hop-mcs" << mcsIndex << "-seed" << seedValue << ".xml";
  monitor->SerializeToXmlFile(fname.str(), true, true);

  Simulator::Destroy();
  rssiStream.close();
  return 0;
}

