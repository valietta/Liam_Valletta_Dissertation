#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/wifi-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include <sstream>

using namespace ns3;

std::ofstream rssiStream;

void MonitorSniffRx(std::string context,
                    Ptr<const Packet> p,
                    uint16_t channelFreqMhz,
                    WifiTxVector txVector,
                    MpduInfo mpduInfo,
                    SignalNoiseDbm signalNoise,
                    uint16_t staId)
{
    double now = Simulator::Now().GetSeconds();
    if (now <= 2.01)
    {
        std::ostringstream log;
        log << now
            << "s RSSI: " << signalNoise.signal
            << " dBm (Noise: " << signalNoise.noise << " dBm)"
            << " on channel " << channelFreqMhz << " MHz"
            << std::endl;
        rssiStream << log.str();
    }
}

int main(int argc, char *argv[])
{
    int seedValue = 1;
    int mcsIndex = 0; // kept for compatibility with filenames

    CommandLine cmd;
    cmd.AddValue("run", "Seed index for the RNG", seedValue);
    cmd.AddValue("mcs", "Wi-Fi MCS index", mcsIndex);
    cmd.Parse(argc, argv);

    SeedManager::SetSeed(12345);
    SeedManager::SetRun(seedValue);

    std::ostringstream rssiname;
    rssiname << "rssi-1hop-mcs" << mcsIndex << "-seed" << seedValue << ".txt";
    rssiStream.open(rssiname.str());

    NodeContainer nodes;
    nodes.Create(2); // 1-hop: source → destination

    // Mobility
    MobilityHelper mobility;
    Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator>();
    positionAlloc->Add(Vector(0.0, 0.0, 0.0));  // Node 0
    positionAlloc->Add(Vector(50.0, 0.0, 0.0));  // Node 1
    mobility.SetPositionAllocator(positionAlloc);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(nodes);

    // Wi-Fi channel (propagation)
    YansWifiChannelHelper channel;
    channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channel.AddPropagationLoss("ns3::ThreeLogDistancePropagationLossModel",
                               "Distance0", DoubleValue(1.0),
                               "Distance1", DoubleValue(50.0),
                               "Distance2", DoubleValue(150.0),
                               "Exponent0", DoubleValue(2.0),
                               "Exponent1", DoubleValue(2.5),
                               "Exponent2", DoubleValue(5.0));
    Ptr<YansWifiChannel> wifiChannel = channel.Create();

    // PHY
    YansWifiPhyHelper phy;
    phy.SetChannel(wifiChannel);

    // Wi-Fi standard must be set before channel settings
    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211be);

    phy.Set("ChannelSettings", StringValue("{0, 160, BAND_5GHZ, 0}"));

    // TX power
    phy.Set("TxPowerStart", DoubleValue(23.0));
    phy.Set("TxPowerEnd", DoubleValue(23.0));

    // Wi-Fi rate control
    wifi.SetRemoteStationManager("ns3::MinstrelHtWifiManager");

    // MAC
    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");
    NetDeviceContainer devices = wifi.Install(phy, mac, nodes);

    // RSSI monitor
    Config::Connect("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Phy/MonitorSnifferRx",
                    MakeCallback(&MonitorSniffRx));

    // IP stack
    InternetStackHelper stack;
    stack.Install(nodes);

    Ipv4AddressHelper address;
    address.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = address.Assign(devices);

    // Traffic
    uint16_t port = 9;
    std::string dataRateStr = "25Mbps";

    OnOffHelper onoff("ns3::UdpSocketFactory", InetSocketAddress(interfaces.GetAddress(1), port));
    onoff.SetConstantRate(DataRate(dataRateStr), 1472);
    onoff.SetAttribute("StartTime", TimeValue(Seconds(2.0)));
    onoff.SetAttribute("StopTime", TimeValue(Seconds(30.0)));
    onoff.Install(nodes.Get(0));

    PacketSinkHelper sink("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), port));
    ApplicationContainer sinkApp = sink.Install(nodes.Get(1));
    sinkApp.Start(Seconds(1.0));
    sinkApp.Stop(Seconds(30.0));

    // Flow Monitor
    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor = flowmon.InstallAll();
    monitor->SetAttribute("StartTime", TimeValue(Seconds(0.0)));

    Simulator::Stop(Seconds(31.0));
    Simulator::Run();

    std::ostringstream fname;
    fname << "wifi7-1hop-mcs" << mcsIndex << "-seed" << seedValue << ".xml";
    monitor->SerializeToXmlFile(fname.str(), true, true);

    Simulator::Destroy();
    rssiStream.close();
    return 0;
}

